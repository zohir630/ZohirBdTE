#!/usr/bin/env bash
# Builds a signed release APK. Needs: JDK 17+, Android SDK (set ANDROID_HOME or local.properties sdk.dir).
set -euo pipefail
cd "$(dirname "$0")"

if [ ! -f keystore.properties ]; then
  echo "Generating a new release keystore (keep release.jks and keystore.properties safe)..."
  PASS="$(head -c 18 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 16)"
  keytool -genkeypair -v -keystore release.jks -alias bdtelecom -keyalg RSA -keysize 2048 \
    -validity 10000 -storepass "$PASS" -keypass "$PASS" \
    -dname "CN=BD Telecom, OU=App, O=BD Telecom, L=Dhaka, C=BD"
  cat > keystore.properties <<EOF
storeFile=release.jks
storePassword=$PASS
keyAlias=bdtelecom
keyPassword=$PASS
EOF
fi

./gradlew --no-daemon assembleRelease
echo "APK: app/build/outputs/apk/release/app-release.apk"
