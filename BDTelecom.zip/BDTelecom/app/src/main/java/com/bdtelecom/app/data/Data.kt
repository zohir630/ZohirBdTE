package com.bdtelecom.app.data

import android.content.Context
import androidx.datastore.preferences.core.doublePreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.longPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

/** A recharge, pack purchase or call charge shown in Usage & History. */
@Entity(tableName = "transactions")
data class TxEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,          // RECHARGE | PACK | CALL
    val title: String,
    val detail: String,
    val amount: Double,
    val timestamp: Long,
)

/** An activated allowance (internet or minutes) that counts down. */
@Entity(tableName = "allowances")
data class AllowanceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val kind: String,          // DATA | VOICE
    val name: String,
    val total: Double,         // GB or minutes
    val remaining: Double,
    val expiresAt: Long,       // 0 = no expiry
)

@Dao
interface AppDao {
    @Query("SELECT * FROM transactions ORDER BY timestamp DESC")
    fun transactions(): Flow<List<TxEntity>>

    @Query("SELECT * FROM allowances ORDER BY expiresAt ASC")
    fun allowances(): Flow<List<AllowanceEntity>>

    @Insert suspend fun insert(tx: TxEntity): Long
    @Insert suspend fun insert(a: AllowanceEntity): Long

    @Query("DELETE FROM transactions WHERE id = :id")
    suspend fun deleteTransaction(id: Long)

    @Query("DELETE FROM transactions")
    suspend fun clearTransactions()
}

@Database(entities = [TxEntity::class, AllowanceEntity::class], version = 1, exportSchema = false)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): AppDao
}

private val Context.store by preferencesDataStore("account")

data class Account(val number: String, val balance: Double, val validity: Long, val type: String)

class Repository(context: Context) {
    private val app = context.applicationContext
    private val db = Room.databaseBuilder(app, AppDb::class.java, "bdtelecom.db").build()
    private val dao = db.dao()

    private val NUMBER = stringPreferencesKey("number")
    private val BALANCE = doublePreferencesKey("balance")
    private val VALIDITY = longPreferencesKey("validity")
    private val TYPE = stringPreferencesKey("type")

    val transactions = dao.transactions()
    val allowances = dao.allowances()

    val account: Flow<Account> = app.store.data.map {
        Account(it[NUMBER] ?: "", it[BALANCE] ?: 0.0, it[VALIDITY] ?: 0L, it[TYPE] ?: "Prepaid")
    }

    suspend fun saveNumber(number: String, type: String) {
        app.store.edit { it[NUMBER] = number; it[TYPE] = type }
    }

    suspend fun recharge(number: String, amount: Double, method: String, now: Long = System.currentTimeMillis()) {
        app.store.edit {
            it[BALANCE] = (it[BALANCE] ?: 0.0) + amount
            it[VALIDITY] = maxOf(it[VALIDITY] ?: 0L, now) + 30L * DAY
        }
        dao.insert(TxEntity(kind = "RECHARGE", title = "Recharged ৳ ${fmt(amount)}",
            detail = "$method Payment Successful • $number", amount = amount, timestamp = now))
    }

    /** Buys a catalog pack from main balance. Returns false when balance is insufficient. */
    suspend fun buyPack(pack: Pack, now: Long = System.currentTimeMillis()): Boolean {
        var ok = false
        app.store.edit {
            val bal = it[BALANCE] ?: 0.0
            if (bal >= pack.price) { it[BALANCE] = bal - pack.price; ok = true }
        }
        if (!ok) return false
        dao.insert(AllowanceEntity(kind = pack.allowanceKind, name = pack.title, total = pack.quantity,
            remaining = pack.quantity, expiresAt = if (pack.validDays == 0) 0L else now + pack.validDays * DAY))
        dao.insert(TxEntity(kind = "PACK", title = "${pack.title} Pack",
            detail = "৳ ${fmt(pack.price)} debited", amount = pack.price, timestamp = now))
        return true
    }

    suspend fun deleteTransaction(id: Long) = dao.deleteTransaction(id)
    suspend fun clearHistory() = dao.clearTransactions()

    companion object { const val DAY = 86_400_000L }
}

fun fmt(v: Double): String =
    if (v % 1.0 == 0.0) "%,d".format(v.toLong()) else "%,.2f".format(v)

/** Pack catalog (the products the operator sells; not user data). */
data class Pack(
    val id: String, val category: String, val title: String,
    val price: Double, val validDays: Int, val allowanceKind: String, val quantity: Double,
) {
    val subtitle get() = "৳ ${fmt(price)} • " + if (validDays == 0) "No Expiry Date" else "Valid for $validDays Days"
}

val PackCatalog = listOf(
    Pack("i15", "Internet", "15 GB Regular Pack", 199.0, 7, "DATA", 15.0),
    Pack("i35", "Internet", "35 GB Monthly Super", 399.0, 30, "DATA", 35.0),
    Pack("i50", "Internet", "50 GB Heavy Streamer", 499.0, 30, "DATA", 50.0),
    Pack("iU", "Internet", "Unlimited 100 GB Data", 999.0, 0, "DATA", 100.0),
    Pack("cF", "Combo", "Friday Special Bundle (30GB + 300 Mins)", 349.0, 30, "DATA", 30.0),
    Pack("m100", "Minutes", "100 Minutes Any-net", 99.0, 7, "VOICE", 100.0),
    Pack("m250", "Minutes", "250 Minutes Any-net", 199.0, 30, "VOICE", 250.0),
    Pack("r1", "Roaming", "Roaming Starter 1 GB", 499.0, 7, "DATA", 1.0),
)
