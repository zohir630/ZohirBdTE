@file:OptIn(ExperimentalMaterial3Api::class)
@file:Suppress("DEPRECATION")

package com.bdtelecom.app.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuAnchorType
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.PrimaryTabRow
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import com.bdtelecom.app.AppViewModel
import com.bdtelecom.app.Routes
import com.bdtelecom.app.data.Pack
import com.bdtelecom.app.data.PackCatalog
import com.bdtelecom.app.data.TxEntity
import com.bdtelecom.app.data.fmt
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val BD_NUMBER = Regex("^01[3-9]\\d{8}$")
private fun cleanNumber(s: String) = s.filter { it.isDigit() }
private fun dateOf(ms: Long) = SimpleDateFormat("d MMM yyyy", Locale.ENGLISH).format(Date(ms))

private fun whenOf(ms: Long): String {
    val now = Calendar.getInstance()
    val t = Calendar.getInstance().apply { timeInMillis = ms }
    val same = now.get(Calendar.YEAR) == t.get(Calendar.YEAR) && now.get(Calendar.DAY_OF_YEAR) == t.get(Calendar.DAY_OF_YEAR)
    val time = SimpleDateFormat("hh:mm a", Locale.ENGLISH).format(Date(ms))
    return if (same) "Today, $time" else SimpleDateFormat("d MMM, hh:mm a", Locale.ENGLISH).format(Date(ms))
}

// ---------- shared chrome ----------

@Composable
fun BottomBar(current: String, onSelect: (String) -> Unit) {
    data class Dest(val route: String, val label: String, val on: ImageVector, val off: ImageVector)
    val dests = listOf(
        Dest(Routes.DASH, "Home", Icons.Rounded.Home, Icons.Outlined.Home),
        Dest(Routes.PACKS, "Offers", Icons.Rounded.LocalOffer, Icons.Outlined.LocalOffer),
        Dest(Routes.HISTORY, "History", Icons.Rounded.History, Icons.Outlined.History),
        Dest(Routes.ACCOUNT, "Account", Icons.Rounded.Person, Icons.Outlined.Person),
    )
    NavigationBar(containerColor = MaterialTheme.colorScheme.surfaceContainer) {
        dests.forEach { d ->
            val selected = d.route == current
            NavigationBarItem(
                selected = selected,
                onClick = { if (!selected) onSelect(d.route) },
                icon = { Icon(if (selected) d.on else d.off, null) },
                label = { Text(d.label, style = MaterialTheme.typography.labelMedium) },
                colors = NavigationBarItemDefaults.colors(indicatorColor = MaterialTheme.colorScheme.secondaryContainer),
            )
        }
    }
}

@Composable
private fun Bar(title: String, onBack: (() -> Unit)?, nav: @Composable () -> Unit = {}, actions: @Composable () -> Unit = {}) {
    TopAppBar(
        title = { Text(title, style = MaterialTheme.typography.titleLarge) },
        navigationIcon = {
            if (onBack != null) IconButton(onBack) { Icon(Icons.Rounded.ArrowBack, "Back") } else nav()
        },
        actions = { actions() },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface,
            scrolledContainerColor = MaterialTheme.colorScheme.surfaceContainer,
        ),
    )
}

private val screenPad = PaddingValues(horizontal = 16.dp, vertical = 8.dp)

// ---------- Dashboard ----------

@Composable
fun DashboardScreen(vm: AppViewModel, push: (String) -> Unit, toast: (String) -> Unit) {
    val account by vm.account.collectAsState()
    val allowances by vm.allowances.collectAsState()
    val now = System.currentTimeMillis()
    var menu by remember { mutableStateOf(false) }
    var showAlerts by remember { mutableStateOf(false) }
    var editNumber by remember { mutableStateOf(false) }

    val live = allowances.filter { it.expiresAt == 0L || it.expiresAt > now }
    val data = live.filter { it.kind == "DATA" }
    val voice = live.filter { it.kind == "VOICE" }

    fun expiresIn(list: List<com.bdtelecom.app.data.AllowanceEntity>): String {
        val next = list.filter { it.expiresAt > 0 }.minOfOrNull { it.expiresAt } ?: return "No expiry"
        val days = ((next - now) / com.bdtelecom.app.data.Repository.DAY).toInt()
        return if (days <= 0) "Expires today" else "Expires in $days days"
    }

    Column(Modifier.fillMaxSize()) {
        Bar("BD Telecom", null,
            nav = {
                Box {
                    IconButton({ menu = true }) { Icon(Icons.Rounded.Menu, "Menu") }
                    DropdownMenu(menu, { menu = false }) {
                        DropdownMenuItem({ Text("Recharge") }, { menu = false; push(Routes.recharge()) },
                            leadingIcon = { Icon(Icons.Rounded.Payments, null) })
                        DropdownMenuItem({ Text("Buy a pack") }, { menu = false; push(Routes.PACKS) },
                            leadingIcon = { Icon(Icons.Rounded.LocalOffer, null) })
                        DropdownMenuItem({ Text("My number") }, { menu = false; editNumber = true },
                            leadingIcon = { Icon(Icons.Rounded.PhoneAndroid, null) })
                    }
                }
            },
            actions = { IconButton({ showAlerts = true }) { Icon(Icons.Rounded.Notifications, "Notifications") } })

        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(screenPad),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            val validity = if (account.validity > now) dateOf(account.validity) else "—"
            val line = if (account.number.isBlank()) "Tap to add your mobile number"
            else "Main Balance • Validity: $validity • ${account.type} ${account.number}"
            InfoCard("৳ ${"%,.2f".format(account.balance)}", line, 130.dp,
                onClick = { editNumber = true })

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                Button(
                    { push(Routes.recharge()) },
                    Modifier.weight(1f).height(56.dp),
                    shape = RoundedCornerShape(topStart = 28.dp, bottomStart = 28.dp, topEnd = 8.dp, bottomEnd = 8.dp),
                ) { Text("Recharge") }
                FilledTonalButton(
                    { push(Routes.PACKS) },
                    Modifier.weight(1f).height(56.dp),
                    shape = RoundedCornerShape(topStart = 8.dp, bottomStart = 8.dp, topEnd = 28.dp, bottomEnd = 28.dp),
                ) { Text("Buy Pack") }
            }

            SectionTitle("Active Allowances")
            if (live.isEmpty()) {
                LinearProgressIndicator({ 0f }, Modifier.fillMaxWidth().height(4.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.secondaryContainer, strokeCap = StrokeCap.Round)
                EmptyState(Icons.Rounded.Wifi, "No active packs",
                    "Buy an internet or minutes pack and your remaining allowance shows up here.")
            } else {
                val dTotal = data.sumOf { it.total }
                val dLeft = data.sumOf { it.remaining }
                LinearProgressIndicator(
                    { if (dTotal > 0) (dLeft / dTotal).toFloat().coerceIn(0f, 1f) else 0f },
                    Modifier.fillMaxWidth().height(4.dp),
                    color = MaterialTheme.colorScheme.primary,
                    trackColor = MaterialTheme.colorScheme.secondaryContainer, strokeCap = StrokeCap.Round,
                )
                val rows = buildList {
                    if (data.isNotEmpty()) add(RowItem("${fmt(dLeft)} GB remaining of ${fmt(dTotal)} GB",
                        "${expiresIn(data)} • High speed 4G", Icons.Rounded.Wifi, Icons.Rounded.ChevronRight,
                        onClick = { push(Routes.HISTORY) }))
                    if (voice.isNotEmpty()) add(RowItem(
                        "${fmt(voice.sumOf { it.remaining })} Mins remaining of ${fmt(voice.sumOf { it.total })} Mins",
                        "Any-net calls • ${expiresIn(voice)}", Icons.Rounded.Call, Icons.Rounded.ChevronRight,
                        onClick = { push(Routes.HISTORY) }))
                }
                StackedList(rows)
            }

            InfoCard("Friday Special Bundle", "Get 30GB + 300 Mins for only ৳ 349. Valid for 30 days.", 120.dp,
                outlined = true, onClick = { push(Routes.PACKS) })
        }
    }

    if (showAlerts) {
        val alerts = buildList {
            if (account.number.isBlank()) add("Add your mobile number to personalise the app.")
            if (account.balance < 50) add("Low balance: ৳ ${"%,.2f".format(account.balance)} left. Recharge to stay connected.")
            live.filter { it.expiresAt > 0 && it.expiresAt - now < 3 * com.bdtelecom.app.data.Repository.DAY }
                .forEach { add("${it.name} expires on ${dateOf(it.expiresAt)}.") }
        }
        AlertDialog(
            onDismissRequest = { showAlerts = false },
            title = { Text("Notifications") },
            text = { Text(if (alerts.isEmpty()) "You're all caught up." else alerts.joinToString("\n\n")) },
            confirmButton = { TextButton({ showAlerts = false }) { Text("Close") } },
            shape = RoundedCornerShape(28.dp),
        )
    }
    if (editNumber) NumberDialog(account.number, account.type, { editNumber = false }) { n, t ->
        vm.saveNumber(n, t); editNumber = false; toast("Number saved")
    }
}

@Composable
fun NumberDialog(number: String, type: String, onDismiss: () -> Unit, onSave: (String, String) -> Unit) {
    var n by remember { mutableStateOf(number) }
    var t by remember { mutableStateOf(type) }
    var error by remember { mutableStateOf<String?>(null) }
    AlertDialog(
        onDismissRequest = onDismiss,
        shape = RoundedCornerShape(28.dp),
        title = { Text("My mobile number") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(n, { n = it; error = null }, Modifier.fillMaxWidth(),
                    label = { Text("Mobile Number") }, singleLine = true, isError = error != null,
                    supportingText = { Text(error ?: "e.g. 01712-345678") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    shape = RoundedCornerShape(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Prepaid", "Postpaid").forEach { opt ->
                        FilterChip(t == opt, { t = opt }, { Text(opt) },
                            leadingIcon = if (t == opt) ({ Icon(Icons.Rounded.Check, null, Modifier.size(18.dp)) }) else null)
                    }
                }
            }
        },
        confirmButton = {
            TextButton({
                val c = cleanNumber(n)
                if (BD_NUMBER.matches(c)) onSave("${c.take(5)}-${c.drop(5)}", t) else error = "Enter a valid 11-digit number"
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } },
    )
}

// ---------- Quick Recharge ----------

@Composable
fun RechargeScreen(vm: AppViewModel, packId: String?, onBack: () -> Unit, toast: (String) -> Unit) {
    val account by vm.account.collectAsState()
    val pack: Pack? = remember(packId) { PackCatalog.find { it.id == packId } }
    var number by remember(account.number) { mutableStateOf(account.number) }
    var amount by remember(pack) { mutableStateOf(pack?.let { fmt(it.price).replace(",", "") } ?: "100") }
    var method by remember { mutableStateOf("bKash") }
    var expanded by remember { mutableStateOf(false) }
    var numberErr by remember { mutableStateOf<String?>(null) }
    var amountErr by remember { mutableStateOf<String?>(null) }
    var showHelp by remember { mutableStateOf(false) }
    var showAuth by remember { mutableStateOf(false) }
    val chips = listOf(50, 100, 200, 500)
    val methods = listOf("bKash", "Nagad", "Rocket", "Debit / Credit Card")
    val amt = amount.toIntOrNull()

    Column(Modifier.fillMaxSize()) {
        Bar("Quick Recharge", onBack, actions = {
            IconButton({ showHelp = true }) { Icon(Icons.Rounded.HelpOutline, "Help") }
        })
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(screenPad),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            if (pack != null) InfoCard("Buying ${pack.title}", "${pack.subtitle}. We'll recharge ৳ ${fmt(pack.price)} and activate it.", 72.dp)

            OutlinedTextField(number, { number = it; numberErr = null }, Modifier.fillMaxWidth(),
                label = { Text("Mobile Number") }, singleLine = true, isError = numberErr != null,
                leadingIcon = { Icon(Icons.Rounded.PhoneAndroid, null) },
                supportingText = { Text(numberErr ?: "Own number or any prepaid/postpaid account") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                shape = RoundedCornerShape(16.dp))

            OutlinedTextField(amount, { amount = it.filter(Char::isDigit).take(5); amountErr = null },
                Modifier.fillMaxWidth(),
                label = { Text("Amount (BDT)") }, singleLine = true, isError = amountErr != null,
                leadingIcon = { Icon(Icons.Rounded.Payments, null) },
                supportingText = { Text(amountErr ?: "Minimum ৳20 • Maximum ৳5,000") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                shape = RoundedCornerShape(16.dp))

            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterHorizontally),
            ) {
                chips.forEachIndexed { i, v ->
                    val sel = amt == v
                    val shape = RoundedCornerShape(
                        topStart = if (i == 0) 16.dp else 4.dp, bottomStart = if (i == 0) 16.dp else 4.dp,
                        topEnd = if (i == chips.lastIndex) 16.dp else 4.dp, bottomEnd = if (i == chips.lastIndex) 16.dp else 4.dp)
                    FilterChip(sel, { amount = v.toString(); amountErr = null }, { Text("৳ $v") },
                        shape = shape,
                        leadingIcon = if (sel) ({ Icon(Icons.Rounded.Check, null, Modifier.size(18.dp)) }) else null)
                }
            }

            ExposedDropdownMenuBox(expanded, { expanded = it }) {
                OutlinedTextField(method, {}, Modifier.fillMaxWidth().menuAnchor(ExposedDropdownMenuAnchorType.PrimaryNotEditable),
                    readOnly = true, label = { Text("Payment Method") },
                    leadingIcon = { Icon(Icons.Rounded.AccountBalance, null) },
                    trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded) },
                    supportingText = { Text("Instant gateway with no extra charge") },
                    shape = RoundedCornerShape(16.dp))
                ExposedDropdownMenu(expanded, { expanded = false }) {
                    methods.forEach { m ->
                        DropdownMenuItem({ Text(m) }, { method = m; expanded = false })
                    }
                }
            }

            Button(
                {
                    val c = cleanNumber(number)
                    numberErr = if (BD_NUMBER.matches(c)) null else "Enter a valid 11-digit number (01XXXXXXXXX)"
                    amountErr = when {
                        amt == null -> "Enter an amount"
                        amt < 20 -> "Minimum recharge is ৳20"
                        amt > 5000 -> "Maximum recharge is ৳5,000"
                        else -> null
                    }
                    if (numberErr == null && amountErr == null) showAuth = true
                },
                Modifier.width(380.dp).height(56.dp).align(Alignment.CenterHorizontally),
            ) {
                Icon(Icons.Rounded.Lock, null, Modifier.size(20.dp))
                Spacer8()
                Text("Recharge ৳ ${amt ?: 0}")
            }
        }
    }

    if (showHelp) AlertDialog(
        onDismissRequest = { showHelp = false }, shape = RoundedCornerShape(28.dp),
        title = { Text("Recharge help") },
        text = { Text("Enter any Bangladeshi mobile number (01X-XXXXXXXX), choose an amount between ৳20 and ৳5,000 and a payment method. You'll confirm with your wallet or card PIN before the recharge is applied.") },
        confirmButton = { TextButton({ showHelp = false }) { Text("Got it") } })

    if (showAuth) {
        var pin by remember { mutableStateOf("") }
        var pinErr by remember { mutableStateOf<String?>(null) }
        val card = method.startsWith("Debit")
        AlertDialog(
            onDismissRequest = { showAuth = false }, shape = RoundedCornerShape(28.dp),
            title = { Text("Pay with $method") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Authenticate ৳ ${amt ?: 0} for ${cleanNumber(number)}.")
                    OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(6); pinErr = null },
                        label = { Text(if (card) "Card OTP" else "$method PIN") }, singleLine = true,
                        isError = pinErr != null, supportingText = { pinErr?.let { Text(it) } },
                        visualTransformation = PasswordVisualTransformation(),
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        shape = RoundedCornerShape(16.dp))
                }
            },
            confirmButton = {
                TextButton({
                    if (pin.length < 4) { pinErr = "Enter at least 4 digits"; return@TextButton }
                    val c = cleanNumber(number)
                    vm.recharge("${c.take(5)}-${c.drop(5)}", (amt ?: 0).toDouble(), method, pack) { msg ->
                        toast(msg)
                    }
                    showAuth = false
                    onBack()
                }) { Text("Confirm") }
            },
            dismissButton = { TextButton({ showAuth = false }) { Text("Cancel") } },
        )
    }
}

@Composable
private fun Spacer8() = androidx.compose.foundation.layout.Spacer(Modifier.width(8.dp))

// ---------- Packs & Offers ----------

@Composable
fun PacksScreen(vm: AppViewModel, push: (String) -> Unit, onBack: () -> Unit, toast: (String) -> Unit) {
    val tabs = listOf("Internet", "Combo", "Minutes", "Roaming")
    var tab by remember { mutableIntStateOf(0) }
    var searching by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }

    val shown = PackCatalog.filter { it.category == tabs[tab] }
        .filter { query.isBlank() || it.title.contains(query, ignoreCase = true) }

    Column(Modifier.fillMaxSize()) {
        Bar(if (searching) "" else "Packs & Bundles", onBack, actions = {
            IconButton({ searching = !searching; if (!searching) query = "" }) {
                Icon(if (searching) Icons.Rounded.Close else Icons.Rounded.Search, "Search")
            }
        })
        if (searching) OutlinedTextField(query, { query = it },
            Modifier.fillMaxWidth().padding(horizontal = 16.dp), singleLine = true,
            placeholder = { Text("Search packs") }, shape = RoundedCornerShape(16.dp),
            leadingIcon = { Icon(Icons.Rounded.Search, null) })
        PrimaryTabRow(tab, containerColor = MaterialTheme.colorScheme.surface) {
            tabs.forEachIndexed { i, t ->
                Tab(tab == i, { tab = i }, text = { Text(t, style = MaterialTheme.typography.titleSmall) },
                    modifier = Modifier.height(48.dp))
            }
        }
        Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(screenPad)) {
            if (shown.isEmpty()) EmptyState(Icons.Rounded.LocalOffer, "No packs found",
                if (query.isBlank()) "There are no packs in this category right now." else "Nothing matches \"$query\".")
            else StackedList(shown.map { p ->
                RowItem(p.title, p.subtitle,
                    if (p.id == "iU") Icons.Rounded.AllInclusive else if (p.allowanceKind == "VOICE") Icons.Rounded.Call else Icons.Rounded.Wifi,
                    Icons.Rounded.AddShoppingCart, onClick = { push(Routes.recharge(p.id)) })
            })
        }
    }
}

// ---------- Usage & History ----------

@Composable
fun HistoryScreen(vm: AppViewModel, push: (String) -> Unit, onBack: () -> Unit, toast: (String) -> Unit) {
    val txs by vm.transactions.collectAsState()
    val allowances by vm.allowances.collectAsState()
    var filter by remember { mutableStateOf("ALL") }
    var menu by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<TxEntity?>(null) }
    var confirmClear by remember { mutableStateOf(false) }

    val cal = Calendar.getInstance()
    val monthName = SimpleDateFormat("MMMM", Locale.ENGLISH).format(cal.time)
    val thisMonth = txs.filter {
        val c = Calendar.getInstance().apply { timeInMillis = it.timestamp }
        c.get(Calendar.MONTH) == cal.get(Calendar.MONTH) && c.get(Calendar.YEAR) == cal.get(Calendar.YEAR)
    }
    val spend = thisMonth.filter { it.kind == "RECHARGE" || it.kind == "CALL" }.sumOf { it.amount }
    val used = allowances.filter { it.kind == "DATA" }.sumOf { it.total - it.remaining }
    val shown = txs.filter { filter == "ALL" || it.kind == filter }

    Column(Modifier.fillMaxSize()) {
        Bar("Usage & History", onBack, actions = {
            Box {
                IconButton({ menu = true }) { Icon(Icons.Rounded.FilterList, "Filter") }
                DropdownMenu(menu, { menu = false }) {
                    listOf("ALL" to "All activity", "RECHARGE" to "Recharges", "PACK" to "Pack purchases", "CALL" to "Calls").forEach { (k, l) ->
                        DropdownMenuItem({ Text(l) }, { filter = k; menu = false },
                            trailingIcon = if (filter == k) ({ Icon(Icons.Rounded.Check, null) }) else null)
                    }
                    DropdownMenuItem({ Text("Clear history") }, { menu = false; confirmClear = true },
                        leadingIcon = { Icon(Icons.Rounded.DeleteSweep, null) })
                }
            }
        })
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(screenPad),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            InfoCard("$monthName Billing Cycle",
                "Total spend this month: ৳ ${fmt(spend)} • Data used: ${fmt(used)} GB", 120.dp)
            SectionTitle("Recent Activity")
            if (shown.isEmpty()) EmptyState(Icons.Rounded.History, "No activity yet",
                "Recharges and pack purchases will appear here.")
            else StackedList(shown.map { t ->
                RowItem(t.title, "${whenOf(t.timestamp)} • ${t.detail}",
                    when (t.kind) { "RECHARGE" -> Icons.Rounded.Payments; "CALL" -> Icons.Rounded.CallMade; else -> Icons.Rounded.Wifi },
                    if (t.kind == "RECHARGE") Icons.Rounded.Check else null,
                    onClick = { selected = t })
            })
        }
    }

    selected?.let { t ->
        AlertDialog(
            onDismissRequest = { selected = null }, shape = RoundedCornerShape(28.dp),
            title = { Text(t.title) },
            text = { Text("${whenOf(t.timestamp)}\n${t.detail}\nAmount: ৳ ${fmt(t.amount)}") },
            confirmButton = { TextButton({ vm.deleteTransaction(t.id); selected = null; toast("Entry deleted") }) { Text("Delete") } },
            dismissButton = { TextButton({ selected = null }) { Text("Close") } },
        )
    }
    if (confirmClear) AlertDialog(
        onDismissRequest = { confirmClear = false }, shape = RoundedCornerShape(28.dp),
        title = { Text("Clear all history?") },
        text = { Text("This removes every recharge and purchase entry from this device. It can't be undone.") },
        confirmButton = { TextButton({ vm.clearHistory(); confirmClear = false; toast("History cleared") }) { Text("Clear") } },
        dismissButton = { TextButton({ confirmClear = false }) { Text("Cancel") } })
}

// ---------- Account ----------

@Composable
fun AccountScreen(vm: AppViewModel, onBack: () -> Unit, toast: (String) -> Unit) {
    val account by vm.account.collectAsState()
    var edit by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        Bar("Account", onBack)
        Column(
            Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(screenPad),
            verticalArrangement = Arrangement.spacedBy(12.dp),
        ) {
            InfoCard("Main Balance: ৳ ${"%,.2f".format(account.balance)}",
                if (account.number.isBlank()) "No number added yet" else "${account.type} • ${account.number}", 100.dp)
            StackedList(listOf(
                RowItem("Mobile number", account.number.ifBlank { "Tap to add your number" },
                    Icons.Rounded.PhoneAndroid, Icons.Rounded.ChevronRight, onClick = { edit = true }),
                RowItem("Account type", account.type, Icons.Rounded.Person, Icons.Rounded.ChevronRight,
                    onClick = { edit = true }),
            ))
        }
    }
    if (edit) NumberDialog(account.number, account.type, { edit = false }) { n, t ->
        vm.saveNumber(n, t); edit = false; toast("Account updated")
    }
}
