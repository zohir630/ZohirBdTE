package com.bdtelecom.app

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.bdtelecom.app.data.Account
import com.bdtelecom.app.data.AllowanceEntity
import com.bdtelecom.app.data.Pack
import com.bdtelecom.app.data.Repository
import com.bdtelecom.app.data.TxEntity
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class AppViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = Repository(app)

    val account: StateFlow<Account> = repo.account.stateIn(
        viewModelScope, SharingStarted.Eagerly, Account("", 0.0, 0L, "Prepaid"))
    val transactions: StateFlow<List<TxEntity>> = repo.transactions.stateIn(
        viewModelScope, SharingStarted.Eagerly, emptyList())
    val allowances: StateFlow<List<AllowanceEntity>> = repo.allowances.stateIn(
        viewModelScope, SharingStarted.Eagerly, emptyList())

    fun saveNumber(number: String, type: String) = viewModelScope.launch { repo.saveNumber(number, type) }

    /** Recharges, then buys [pack] from the new balance when one was chosen. [done] gets a result message. */
    fun recharge(number: String, amount: Double, method: String, pack: Pack?, done: (String) -> Unit) {
        viewModelScope.launch {
            repo.recharge(number, amount, method)
            if (pack != null) {
                val ok = repo.buyPack(pack)
                done(if (ok) "Recharged ৳ ${com.bdtelecom.app.data.fmt(amount)} and activated ${pack.title}"
                else "Recharged, but balance is too low to activate ${pack.title}")
            } else done("Recharged ৳ ${com.bdtelecom.app.data.fmt(amount)} successfully")
        }
    }

    fun buyPack(pack: Pack, done: (String) -> Unit) {
        viewModelScope.launch {
            done(if (repo.buyPack(pack)) "${pack.title} activated" else "Not enough balance for ${pack.title}")
        }
    }

    fun deleteTransaction(id: Long) = viewModelScope.launch { repo.deleteTransaction(id) }
    fun clearHistory() = viewModelScope.launch { repo.clearHistory() }
}
