package com.bdtelecom.app.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.ListItem
import androidx.compose.material3.ListItemDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedCard
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp

/** Slight press-scale on top of the default ripple. */
@Composable
fun Modifier.pressScale(source: MutableInteractionSource): Modifier {
    val pressed by source.collectIsPressedAsState()
    val s by animateFloatAsState(
        if (pressed) 0.97f else 1f,
        spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMedium),
        label = "press",
    )
    return this.scale(s)
}

data class RowItem(
    val title: String,
    val supporting: String,
    val icon: ImageVector,
    val trailing: ImageVector? = null,
    val onClick: (() -> Unit)? = null,
    val onTrailingClick: (() -> Unit)? = null,
)

/** M3 Expressive stacked list: 3dp gaps, 28dp outer corners, 8dp inner corners. */
@Composable
fun StackedList(items: List<RowItem>, modifier: Modifier = Modifier) {
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        items.forEachIndexed { i, item ->
            val outer = 28.dp
            val inner = 8.dp
            val shape = RoundedCornerShape(
                topStart = if (i == 0) outer else inner, topEnd = if (i == 0) outer else inner,
                bottomStart = if (i == items.lastIndex) outer else inner,
                bottomEnd = if (i == items.lastIndex) outer else inner,
            )
            val source = remember { MutableInteractionSource() }
            Surface(
                shape = shape,
                color = MaterialTheme.colorScheme.surfaceContainerLow,
                modifier = Modifier.fillMaxWidth().pressScale(source),
            ) {
                ListItem(
                    modifier = Modifier.height(72.dp).let {
                        if (item.onClick != null)
                            it.clickable(interactionSource = source, indication = androidx.compose.material3.ripple(), onClick = item.onClick)
                        else it
                    },
                    colors = ListItemDefaults.colors(containerColor = androidx.compose.ui.graphics.Color.Transparent),
                    leadingContent = {
                        Box(
                            Modifier.size(40.dp).background(MaterialTheme.colorScheme.primaryContainer, CircleShape),
                            contentAlignment = Alignment.Center,
                        ) {
                            Icon(item.icon, null, Modifier.size(24.dp), tint = MaterialTheme.colorScheme.onPrimaryContainer)
                        }
                    },
                    headlineContent = { Text(item.title, style = MaterialTheme.typography.bodyLarge, maxLines = 1) },
                    supportingContent = {
                        Text(item.supporting, style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
                    },
                    trailingContent = item.trailing?.let { t ->
                        { Icon(t, null, tint = MaterialTheme.colorScheme.onSurfaceVariant) }
                    },
                )
            }
        }
    }
}

@Composable
fun InfoCard(
    headline: String,
    body: String,
    height: androidx.compose.ui.unit.Dp,
    outlined: Boolean = false,
    onClick: (() -> Unit)? = null,
) {
    val source = remember { MutableInteractionSource() }
    val content: @Composable () -> Unit = {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(headline, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurface)
            Text(body, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
    val mod = Modifier.fillMaxWidth().heightIn(min = height).pressScale(source)
    val shape = RoundedCornerShape(20.dp)
    if (outlined) {
        if (onClick != null)
            OutlinedCard(onClick, mod, shape = shape, interactionSource = source,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) { content() }
        else OutlinedCard(mod, shape = shape, border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) { content() }
    } else {
        val colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHighest)
        if (onClick != null) Card(onClick, mod, shape = shape, colors = colors, interactionSource = source) { content() }
        else Card(mod, shape = shape, colors = colors) { content() }
    }
}

@Composable
fun SectionTitle(text: String) {
    Text(text, style = MaterialTheme.typography.titleLarge.copy(
        fontSize = androidx.compose.ui.unit.TextUnit(20f, androidx.compose.ui.unit.TextUnitType.Sp),
        fontWeight = androidx.compose.ui.text.font.FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
        modifier = Modifier.fillMaxWidth())
}

@Composable
fun EmptyState(icon: ImageVector, title: String, message: String) {
    Column(Modifier.fillMaxWidth().padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Icon(icon, null, Modifier.size(40.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
        Text(title, style = MaterialTheme.typography.titleMedium)
        Text(message, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
