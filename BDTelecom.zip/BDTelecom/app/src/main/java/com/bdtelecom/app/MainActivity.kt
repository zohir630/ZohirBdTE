package com.bdtelecom.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContentTransitionScope
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.navigation.NavBackStackEntry
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.bdtelecom.app.ui.AccountScreen
import com.bdtelecom.app.ui.BottomBar
import com.bdtelecom.app.ui.DashboardScreen
import com.bdtelecom.app.ui.HistoryScreen
import com.bdtelecom.app.ui.PacksScreen
import com.bdtelecom.app.ui.RechargeScreen
import com.bdtelecom.app.ui.theme.BDTelecomTheme
import kotlinx.coroutines.launch

object Routes {
    const val DASH = "dashboard"
    const val RECHARGE = "recharge?pack={pack}"
    const val PACKS = "packs"
    const val HISTORY = "history"
    const val ACCOUNT = "account"
    fun recharge(packId: String? = null) = if (packId == null) "recharge" else "recharge?pack=$packId"
}

class MainActivity : ComponentActivity() {
    private val vm: AppViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { BDTelecomTheme { AppRoot(vm) } }
    }
}

/** Whether the next navigation should slide (pushed screens) instead of fade (nav bar). */
private var slideNext = false

@Composable
private fun AppRoot(vm: AppViewModel) {
    val nav = rememberNavController()
    val snack = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()
    val entry by nav.currentBackStackEntryAsState()
    val route = entry?.destination?.route
    val topLevel = listOf(Routes.DASH, Routes.PACKS, Routes.HISTORY, Routes.ACCOUNT)

    val show: (String) -> Unit = { msg -> scope.launch { snack.showSnackbar(msg) } }
    val push: (String) -> Unit = { r -> slideNext = true; nav.navigate(r) { launchSingleTop = true } }
    val tab: (String) -> Unit = { r ->
        slideNext = false
        if (r == Routes.DASH) nav.popBackStack(Routes.DASH, inclusive = false)
        else nav.navigate(r) {
            popUpTo(Routes.DASH) { saveState = false }
            launchSingleTop = true
        }
    }
    val back: () -> Unit = { slideNext = true; if (!nav.popBackStack()) tab(Routes.DASH) }

    val springSpec = spring<androidx.compose.ui.unit.IntOffset>(Spring.DampingRatioLowBouncy, Spring.StiffnessMediumLow)
    val enter: AnimatedContentTransitionScope<NavBackStackEntry>.() -> EnterTransition = {
        if (slideNext) slideInHorizontally(springSpec) { it } else fadeIn()
    }
    val exit: AnimatedContentTransitionScope<NavBackStackEntry>.() -> ExitTransition = {
        if (slideNext) slideOutHorizontally(springSpec) { -it / 4 } + fadeOut() else fadeOut()
    }
    val popEnter: AnimatedContentTransitionScope<NavBackStackEntry>.() -> EnterTransition = {
        if (slideNext) slideInHorizontally(springSpec) { -it / 4 } + fadeIn() else fadeIn()
    }
    val popExit: AnimatedContentTransitionScope<NavBackStackEntry>.() -> ExitTransition = {
        if (slideNext) slideOutHorizontally(springSpec) { it } else fadeOut()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.surface,
        snackbarHost = { SnackbarHost(snack) },
        bottomBar = { if (route in topLevel) BottomBar(route!!, tab) },
    ) { pad ->
        Box(Modifier.fillMaxSize().padding(bottom = pad.calculateBottomPadding())) {
            NavHost(nav, Routes.DASH, enterTransition = enter, exitTransition = exit,
                popEnterTransition = popEnter, popExitTransition = popExit) {
                composable(Routes.DASH) { DashboardScreen(vm, push, show) }
                composable(
                    Routes.RECHARGE,
                    arguments = listOf(navArgument("pack") { type = NavType.StringType; nullable = true; defaultValue = null }),
                ) { RechargeScreen(vm, it.arguments?.getString("pack"), back, show) }
                composable(Routes.PACKS) { PacksScreen(vm, push, back, show) }
                composable(Routes.HISTORY) { HistoryScreen(vm, push, back, show) }
                composable(Routes.ACCOUNT) { AccountScreen(vm, back, show) }
            }
        }
    }
}
